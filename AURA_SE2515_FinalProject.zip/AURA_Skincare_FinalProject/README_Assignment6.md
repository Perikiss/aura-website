# AURA Skincare — Assignment 6 (jQuery)

## Setup
Open `index.html` with Live Server. jQuery 3.7.1 is loaded from the official jQuery CDN in each HTML page. The external JavaScript file is `js/script.js`. Open browser Developer Tools → Console to see `jQuery is ready!`.

## Implemented tasks
0. jQuery CDN and `$(document).ready()` setup.
1. Real-time product search on Collection.
2. Autocomplete suggestions while typing product names.
3. Matching search terms are highlighted in product results; FAQ search highlights matching text.
4. Pink scroll progress bar at the top of each page.
5. Animated counters in the Home page statistics section.
6. Contact form submit button displays a spinner and “Please wait…” while the demo submission runs, then returns to normal.
7. Temporary toast notifications confirm product interactions and other actions.
8. Copy promo code button copies `AURAGLOW20`, changes to a checkmark, and displays a toast.
9. Images use `data-src` and are loaded when they approach the viewport using jQuery scroll handling.

## Technologies
HTML, CSS, JavaScript, jQuery 3.7.1. The contact form is a front-end demonstration and does not send information to a server.
