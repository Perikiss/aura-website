# AURA Skincare — Assignment 5

Team: AURA Dev Team  
Members: Perizat and Adema  
Group: SE-2515  
Theme: Skincare / Beauty

## Project structure
- `index.html` — home page, Read More interaction and FAQ.
- `about.html` — brand story and team.
- `collection.html` — product cards rendered with JavaScript, category filters and star ratings.
- `contact.html` — contact form, asynchronous demo submission and reset button.
- `css/style.css` — all styles, themes, transitions and animations.
- `js/script.js` — all JavaScript behavior, event handlers, translations and product data.
- `images/` — team member photos from the original project.

## Run locally
1. Extract the ZIP folder.
2. Open the `aura-website` folder in VS Code.
3. Install/use the Live Server extension, then right-click `index.html` and choose **Open with Live Server**. You can also open `index.html` directly in a browser.
4. Test the header controls, Read More, FAQ, product filters and star ratings, contact form, keyboard navigation, and language selector.

## Assignment 5 feature map
1. **DOM manipulation and styling:** `querySelector`, `querySelectorAll`, `getElementById`, `textContent`, `innerHTML`, class changes, theme toggle, background color changes and Read More.
2. **Event handling:** click/change/keydown/submit events, arrow-key navigation, reset form and current-time button.
3. **Callbacks and switch:** event listener callbacks, async contact form demonstration and `switch` for language selection.
4. **Objects, arrays, loops and higher-order functions:** product objects in an array, `filter`, `map`, `forEach` and loops.
5. **Sound and animations:** Web Audio API tone on user interaction, CSS transitions, card animation and IntersectionObserver reveal animation.
6. **Separation of concerns:** HTML, CSS and JavaScript are stored in separate files.

## Important note about the contact form
The form demonstrates asynchronous behavior and displays a success message without reloading the page. It does **not** send personal data to a real server because the project does not have a backend/API configured.

## Deployment
The previous project URL was `https://perikiss.github.io/aura-website/`. After pushing these changes to the shared GitHub repository, wait for GitHub Pages to rebuild and open that URL to verify the new version. Include the confirmed working URL in the final report.
